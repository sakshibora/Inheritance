/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication8;
class A
{
    int a,b,c;
    A(int a, int b)
    {
        this.a = a;
        this.b = b;
    }
    void add()
    {
        c = a+b;
    }
    void display()
    {
        System.out.println("Sum is: " +c);
    }
}

class B extends A
{
    B(int a, int b)
    {
        super(a ,b);
        
    }
    void add()
    {
        c= a+b;
    }
}
/**
 * 
 *
 * @author king
 */
public class JavaApplication8 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      B obj = new B(23,76);
      obj.add();
      obj.display();
      

// TODO code application logic here
    }
    
}
